window.__imported__ = window.__imported__ || {};
window.__imported__["thermo@3x/layers.json.js"] = [
	{
		"objectId": "82A1B20C-3D4A-4175-BE42-689FA865796E",
		"kind": "artboard",
		"name": "Mobile_Portrait",
		"maskFrame": null,
		"layerFrame": {
			"x": 416,
			"y": 128,
			"width": 360,
			"height": 640
		},
		"visible": true,
		"metadata": {},
		"backgroundColor": "rgba(255, 255, 255, 1)",
		"children": [
			{
				"objectId": "5304C5F2-49ED-484B-86DF-C694AB0E3713",
				"kind": "group",
				"name": "dash",
				"maskFrame": null,
				"layerFrame": {
					"x": 34,
					"y": 174,
					"width": 292,
					"height": 292
				},
				"visible": true,
				"metadata": {
					"opacity": 1
				},
				"image": {
					"path": "images/Layer-dash-ntmwnem1.png",
					"frame": {
						"x": 34,
						"y": 174,
						"width": 292,
						"height": 292
					}
				},
				"children": [],
				"time": 145
			}
		],
		"time": 152
	}
]