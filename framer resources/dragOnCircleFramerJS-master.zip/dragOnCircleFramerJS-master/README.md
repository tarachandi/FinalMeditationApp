# dragOnCircleFramerJS
Framer JS module that allows you to drag layer on circle with defined radius

add module to your project

write
```
dragOnCircle = require "dragOnCircle"
```

then run function

```
angle=dragOnCircle.circleDrag layer, 100
# where layer is layer name, 100 radius
```

![dragging along circle](https://github.com/mamezito/dragOnCircleFramerJS/blob/master/knob.gif)


live sample
http://tr.im/FramerKnob 
